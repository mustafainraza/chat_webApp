const client = require('./connection.js')
const express = require('express');
const app = express();
app.use(express.json());
const message = require('./consumer.js')
const dets = require('./producer.js')


time =  new Date(Date.now()).getHours() +":" + new Date(Date.now()).getMinutes()+":" + new Date(Date.now()).getSeconds()
console.log(dets.room_id, dets.author, dets.message, time, dets.client_email )

client.connect(function(err) {
    if (err) {
      return console.error('error: ' + err.message);
    }
    console.log('Connected to the DB .');
  });

// app.get('/users', (req, res)=>{
//     client.query(`Select * from users`, (err, result)=>{
//         if(!err){
//             res.send(result.rows);
//         }
//     });
    
// })

app.post('/addData', (req, res) => {
    try {
        console.log("sending to db");
        //wait
        //const {room_id, author, message, client_email } = req.body
        time =  new Date(Date.now()).getHours() +":" + new Date(Date.now()).getMinutes()+":" + new Date(Date.now()).getSeconds()
        console.log(dets.room_id, dets.author, dets.message, time, dets.client_email)
        const newMsg =  client.query(
            'INSERT INTO message (room_id, author, message,time, client_email) VALUES ($1, $2, $3, $4, $5) RETURNING *',[room_id, author, message,time, client_email]
        );
        res.send(newMsg);
        console.log("Data Posted");
    } catch (err) {
        console.error(err.message);
    }
});

app.listen(3000, ()=>{
    console.log("Sever is now listening at port 3000");
})

